#!/bin/bash

# Configuración
ZONE_ID="da500a3ba56177482dd1a0e42dc2e68b"
RECORD_ID="1efaf65c928ded91fc87b3aca176af7b"
API_TOKEN="Txcx7396KIdyj7wxTy1idPjeOUUar3VJIP92_AV4"
RECORD_NAME="kirihadeploy.website"

# Obtén la IP pública actual
IP_PUBLICA=$(curl -s http://ipv4.icanhazip.com)

# Obtén la IP actual en Cloudflare
IP_CLOUDFLARE=$(curl -s -X GET "https://api.cloudflare.com/client/v4/zones/$ZONE_ID/dns_records/$RECORD_ID" \
  -H "Authorization: Bearer $API_TOKEN" \
  -H "Content-Type: application/json" | jq -r '.result.content')

# Si la IP ha cambiado, actualiza Cloudflare
if [ "$IP_PUBLICA" != "$IP_CLOUDFLARE" ]; then
  echo "Actualizando la IP de $RECORD_NAME de $IP_CLOUDFLARE a $IP_PUBLICA..."
  curl -s -X PUT "https://api.cloudflare.com/client/v4/zones/$ZONE_ID/dns_records/$RECORD_ID" \
    -H "Authorization: Bearer $API_TOKEN" \
    -H "Content-Type: application/json" \
    --data '{
      "type": "A",
      "name": "'$RECORD_NAME'",
      "content": "'$IP_PUBLICA'",
      "ttl": 120,
      "proxied": true
    }'
  echo "IP actualizada correctamente en Cloudflare."
else
  echo "La IP ya está actualizada. No se realizaron cambios."
fi
