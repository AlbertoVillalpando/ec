# CORA



## Herramientas

    Django
    Contenedor Docker
    HTML
    CSS
    JS
    Bootstrap

## Correr el sistema en pruebas

docker network create proxy

docker-compose up -d --build

docker-compose exec web bash

python3 manage.py check

python3 manage.py makemigrations

python3 manage.py migrate

python3 manage.py runserver 0.0.0.0:8000

## Correr pruebas de integracion

docker-compose up -d --build

docker-compose exec web bash

coverage run --branch --source='.' --omit=test,migrations,__init,settings,apps,wsgi,*admin.py,*asgi.py,manage.py,*urls.py manage.py test

coverage report -m --fail-under 80

#### Si quieres ver archivo por archivo cual es el porcentaje se tiene que ejecutar:

coverage html

#### Este comando creara la carpeta llamada htmlcov, hay que entrar en esa carpeta y abrir en el navegador el index

## Pruebas BEHAVE

cd .\pruebas_aceptacion\CORA\

behave

## Usuarios de prueba
#### En caso de requerir hacer pruebas para los diferentes tipos de usuario se pueden usar las siguientes credenciales:

- adminP@adminP.com
- organizadorP@organizadorP.com
- revisorP@revisorP.com
- autorP@autorP.com

Para todos la contraseña es: P123456789
