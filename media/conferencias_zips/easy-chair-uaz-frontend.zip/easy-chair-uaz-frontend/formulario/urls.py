from django.urls import path
from . import views

urlpatterns = [
    path('crear/<int:conferencia_id>/', views.crear_formulario, name='crear_formulario'),
    path('ver/<int:conferencia_id>/', views.ver_formulario, name='ver_formulario'),
]
