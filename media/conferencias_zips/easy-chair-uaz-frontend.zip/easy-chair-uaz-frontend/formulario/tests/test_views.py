from django.test import TestCase, Client
from django.urls import reverse
from conferencia.models import Conferencia
from formulario.models import Pregunta, Respuesta

class FormularioViewsTest(TestCase):
    def setUp(self):
        self.client = Client()
        self.conferencia = Conferencia.objects.create(nombre="Conf de prueba")
        self.crear_url = reverse('crear_formulario', args=[self.conferencia.id])
        self.ver_url = reverse('ver_formulario', args=[self.conferencia.id])

    def test_crear_formulario_get(self):
        response = self.client.get(self.crear_url)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'formulario/crear_formulario.html')

    def test_crear_formulario_post_valido(self):
        response = self.client.post(self.crear_url, data={'preguntas': ['Pregunta 1', 'Pregunta 2']})
        self.assertEqual(Pregunta.objects.filter(conferencia=self.conferencia).count(), 2)

    def test_crear_formulario_post_vacio(self):
        response = self.client.post(self.crear_url, data={'preguntas': ['   ', '']})
        self.assertEqual(Pregunta.objects.filter(conferencia=self.conferencia).count(), 0)

    def test_ver_formulario_get(self):
        Pregunta.objects.create(conferencia=self.conferencia, texto="¿Cómo evalúas?")
        response = self.client.get(self.ver_url)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'formulario/ver_formulario.html')
        self.assertContains(response, "¿Cómo evalúas?")

    def test_ver_formulario_post_respuestas_validas(self):
        p1 = Pregunta.objects.create(conferencia=self.conferencia, texto="P1")
        p2 = Pregunta.objects.create(conferencia=self.conferencia, texto="P2")
        data = {f"respuesta_{p1.id}": "4", f"respuesta_{p2.id}": "5"}
        response = self.client.post(self.ver_url, data=data)
        self.assertEqual(Respuesta.objects.count(), 2)
        self.assertRedirects(response, reverse('conferencia'))

    def test_ver_formulario_post_sin_respuestas(self):
        Pregunta.objects.create(conferencia=self.conferencia, texto="P1")
        response = self.client.post(self.ver_url, data={})
        self.assertEqual(Respuesta.objects.count(), 0)
