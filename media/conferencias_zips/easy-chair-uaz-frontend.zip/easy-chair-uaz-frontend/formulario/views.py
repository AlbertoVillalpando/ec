from django.shortcuts import render, redirect, get_object_or_404
from conferencia.models import Conferencia
from formulario.models import Pregunta, Respuesta
from django.contrib.auth.decorators import login_required

@login_required
def crear_formulario(request, conferencia_id):
    conferencia = get_object_or_404(Conferencia, id=conferencia_id)

    if request.method == 'POST':
        preguntas = request.POST.getlist('preguntas')
        for texto in preguntas:
            if texto.strip():
                Pregunta.objects.create(conferencia=conferencia, texto=texto.strip())
        return redirect('conferencia')

    preguntas_existentes = conferencia.preguntas.all()  # related_name

    return render(request, 'formulario/crear_formulario.html', {
        'conferencia': conferencia,
        'preguntas_existentes': preguntas_existentes
    })

@login_required
def ver_formulario(request, conferencia_id):
    conferencia = get_object_or_404(Conferencia, id=conferencia_id)
    preguntas = Pregunta.objects.filter(conferencia=conferencia)

    if request.method == 'POST':
        for pregunta in preguntas:
            puntaje = request.POST.get(f"respuesta_{pregunta.id}")
            if puntaje:
                Respuesta.objects.create(
                    pregunta=pregunta,
                    puntaje=int(puntaje)
                )
        return redirect('conferencia')  # Redirige a donde prefieras

    return render(request, 'formulario/ver_formulario.html', {
        'conferencia': conferencia,
        'preguntas': preguntas
    })