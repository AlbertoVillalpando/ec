from django.db import models
from conferencia.models import Conferencia

class Pregunta(models.Model):
    conferencia = models.ForeignKey(Conferencia, on_delete=models.CASCADE, related_name='preguntas')
    texto = models.CharField(max_length=255)

    def __str__(self):
        return self.texto

class Respuesta(models.Model):
    pregunta = models.ForeignKey(Pregunta, on_delete=models.CASCADE)
    puntaje = models.IntegerField(choices=[(i, str(i)) for i in range(1, 6)])

    def __str__(self):
        return f"{self.pregunta} - {self.puntaje}"
