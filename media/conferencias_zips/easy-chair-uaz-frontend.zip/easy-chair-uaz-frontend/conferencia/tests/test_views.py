from django.test import TestCase
from django.urls import reverse
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.core.files.uploadedfile import SimpleUploadedFile
from conferencia.models import Conferencia

User = get_user_model()

class ConferenciaViewTestCase(TestCase):
    def setUp(self):
        self.org_group = Group.objects.create(name='Organizador')
        self.autor_group = Group.objects.create(name='Autor')
        self.organizador = User.objects.create_user(username='org', password='pass', email='org@example.com')
        self.autor = User.objects.create_user(username='aut', password='pass', email='aut@example.com')
        self.org_group.user_set.add(self.organizador)
        self.autor_group.user_set.add(self.autor)
        self.conferencia = Conferencia.objects.create(
            nombre='Conf Inicial', meses=1, dias=1, horas=1, minutos=0,
            organizador=self.organizador, autor=self.autor
        )
        # Autenticar usuario organizador
        self.client.force_login(self.organizador)

    def test_conferencias_list_view_authenticated(self):
        url = reverse('conferencia')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'conferencia/conferencias.html')
        self.assertIn('conferencias', response.context)

    def test_conferencia_create_view_get(self):
        url = reverse('crear_conferencia')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'conferencia/crear_conferencia.html')

    def test_conferencia_create_view_post_valid(self):
        url = reverse('crear_conferencia')
        data = {
            'nombre': 'Nueva Conf', 'meses': 0, 'dias': 2, 'horas': 3, 'minutos': 30,
            'organizador': self.organizador.id, 'autor': self.autor.id
        }
        response = self.client.post(url, data)
        self.assertRedirects(response, reverse('conferencia'))
        self.assertTrue(Conferencia.objects.filter(nombre='Nueva Conf').exists())

    def test_conferencia_create_view_post_invalid(self):
        url = reverse('crear_conferencia')
        data = {'nombre': '', 'meses': 'x'}
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'conferencia/crear_conferencia.html')
        form = response.context.get('form')
        self.assertIsNotNone(form)
        self.assertFalse(form.is_valid())
        self.assertIn('nombre', form.errors)

    def test_conferencia_update_view_get(self):
        url = reverse('editar_conferencia', args=[self.conferencia.pk])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'conferencia/editar.html')
        self.assertIn('form', response.context)

    def test_conferencia_update_view_post_valid(self):
        url = reverse('editar_conferencia', args=[self.conferencia.pk])
        data = {
            'nombre': 'Updated', 'meses': 2, 'dias': 3, 'horas': 0, 'minutos': 15,
            'organizador': self.organizador.id, 'autor': self.autor.id
        }
        response = self.client.post(url, data)
        self.assertRedirects(response, reverse('conferencia'))
        self.conferencia.refresh_from_db()
        self.assertEqual(self.conferencia.nombre, 'Updated')

    def test_conferencia_update_view_post_invalid(self):
        url = reverse('editar_conferencia', args=[self.conferencia.pk])
        data = {'nombre': '', 'meses': -1}
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'conferencia/editar.html')
        form = response.context.get('form')
        self.assertIsNotNone(form)
        self.assertFalse(form.is_valid())
        self.assertIn('nombre', form.errors)

    def test_subir_documentos_view_get(self):
        url = reverse('subir_documentos', args=[self.conferencia.pk])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'conferencia/subir_documentos.html')
        self.assertIn('conferencia', response.context)

    def test_subir_documento_zip_valido(self):
        url = reverse('subir_documentos', args=[self.conferencia.pk])
        archivo = SimpleUploadedFile('doc.zip', b'data', content_type='application/zip')
        response = self.client.post(url, {'archivo': archivo})
        self.assertRedirects(response, reverse('conferencia'))
        self.conferencia.refresh_from_db()
        self.assertTrue(self.conferencia.archivo_zip.name)
        self.assertIn('.zip', self.conferencia.archivo_zip.name)

    def test_subir_documento_invalido_no_file(self):
        url = reverse('subir_documentos', args=[self.conferencia.pk])
        response = self.client.post(url, {})
        self.assertRedirects(response, url)

    def test_subir_documento_invalido_wrong_type(self):
        url = reverse('subir_documentos', args=[self.conferencia.pk])
        archivo = SimpleUploadedFile('doc.txt', b'data', content_type='text/plain')
        response = self.client.post(url, {'archivo': archivo})
        self.assertRedirects(response, url)
