from pyexpat.errors import messages
from django.shortcuts import render, redirect, get_object_or_404
from .models import Conferencia
from django.http import HttpResponseRedirect
from .forms import ConferenciaForm
from django.contrib.auth.models import Group
from django.http import JsonResponse
from usuarios.models import CustomUser
from .models import InvitacionRevisor, Conferencia
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
from django.shortcuts import get_object_or_404
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.http import HttpResponseBadRequest
from django.contrib.auth.decorators import login_required


User = get_user_model()

@login_required
def conferencias_view(request):
    user = request.user
    es_revisor = user.groups.filter(name='Revisor').exists()

    # Filtrar conferencias según el grupo al que pertenece el usuario
    if user.groups.filter(name="Administrador").exists():
        conferencias = Conferencia.objects.all()
    elif user.groups.filter(name="Organizador").exists():
        conferencias = Conferencia.objects.filter(organizador=user)
    elif user.groups.filter(name="Autor").exists():
        conferencias = Conferencia.objects.filter(autor=user)
    elif es_revisor:
        # Filtrar las conferencias donde el usuario es revisor
        conferencias = Conferencia.objects.filter(
            invitaciones_revisor__autor=user,
            invitaciones_revisor__estado='aceptado'
        )
    else:
        conferencias = Conferencia.objects.none()

    # Otros filtros y datos para la plantilla
    autores = CustomUser.objects.filter(groups__name='Autor')
    es_autor = user.groups.filter(name="Autor").exists()

    return render(request, 'conferencia/conferencias.html', {
        'conferencias': conferencias,
        'autores': autores,
        'es_autor': es_autor,
        'es_revisor': es_revisor,
    })


@login_required
def evaluar_conferencia(request, conferencia_id):
    conferencia = get_object_or_404(Conferencia, id=conferencia_id)
    preguntas = conferencia.preguntas.all()  # si usas related_name='preguntas'

    return render(request, 'conferencia/evaluar_conferencia.html', {
        'conferencia': conferencia,
        'preguntas': preguntas,
    })

@login_required
def subir_documentos_view(request, pk):
    conferencia = get_object_or_404(Conferencia, pk=pk)

    if request.method == 'POST':
        archivo = request.FILES.get('archivo')

        if not archivo:
            return redirect(request.path)

        if not archivo.name.endswith('.zip'):
            return redirect(request.path)

        conferencia.archivo_zip = archivo
        conferencia.save()

        return redirect('conferencia')

    return render(request, 'conferencia/subir_documentos.html', {'conferencia': conferencia})

@login_required
def crear_conferencia_view(request):
    if request.method == 'POST':
        form = ConferenciaForm(request.POST)
        if form.is_valid():
            form.save()  
            return redirect('conferencia')
    else:
        form = ConferenciaForm()

    return render(request, 'conferencia/crear_conferencia.html', {'form': form})


@login_required
def editar_conferencia(request, pk):
    conferencia = get_object_or_404(Conferencia, pk=pk)
    if request.method == 'POST':
        form = ConferenciaForm(request.POST, instance=conferencia)
        if form.is_valid():
            form.save()
            return redirect('conferencia')
    else:
        form = ConferenciaForm(instance=conferencia)
    return render(request, 'conferencia/editar.html', {'form': form})


@login_required
def eliminar_conferencia(request, pk):
    conferencia = get_object_or_404(Conferencia, pk=pk)
    conferencia.delete()
    return redirect('conferencia')


@login_required
def autores_disponibles(request, conferencia_id):
    autores = CustomUser.objects.filter(groups__name='Autor')
    invitados_ids = InvitacionRevisor.objects.filter(conferencia_id=conferencia_id).values_list('autor_id', flat=True)
    disponibles = autores.exclude(id__in=invitados_ids)

    data = [
        {"id": autor.id, "nombre": f"{autor.nombre} {autor.apellidos}", "email": autor.email}
        for autor in disponibles
    ]
    return JsonResponse(data, safe=False)


@login_required
def ver_invitaciones_conferencia(request, conferencia_id):
    conferencia = get_object_or_404(Conferencia, id=conferencia_id)
    invitaciones = InvitacionRevisor.objects.filter(conferencia=conferencia)
    
    # Filtrar autores disponibles (que no hayan sido invitados aún)
    autores_disponibles = CustomUser.objects.exclude(id__in=invitaciones.values('autor_id'))
    
    return render(request, 'conferencia/invitaciones_conferencia.html', {
        'conferencia': conferencia,
        'invitaciones': invitaciones,
        'autores_disponibles': autores_disponibles,
    })


@login_required
def responder_invitacion(request, invitacion_id, accion):
    invitacion = get_object_or_404(InvitacionRevisor, id=invitacion_id)

    if accion == 'Aceptar':
        # Cambiar el estado de la invitación a 'aceptado'
        invitacion.estado = 'aceptado'
        invitacion.save()

        # Asignar el rol de Revisor al autor que aceptó la invitación
        autor = invitacion.autor
        revisor_group, _ = Group.objects.get_or_create(name='Revisor')
        autor.groups.add(revisor_group)  # Añadir el usuario al grupo de Revisores

        # Mensaje de éxito
        messages.success(request, f"¡Has aceptado la invitación y ahora eres revisor de la conferencia {invitacion.conferencia.nombre}!")

    elif accion == 'Rechazar':
        # Cambiar el estado de la invitación a 'rechazado'
        invitacion.estado = 'rechazado'
        invitacion.save()

        # Mensaje de rechazo
        messages.info(request, f"Has rechazado la invitación para la conferencia {invitacion.conferencia.nombre}.")

    # Redirigir a la página de invitaciones de la conferencia
    return redirect('conferencia/invitaciones_conferencia.html', conferencia_id=invitacion.conferencia.id)

@login_required
def invitar_autor(request, conferencia_id):
    conferencia = get_object_or_404(Conferencia, id=conferencia_id)
    
    if request.method == 'POST':
        autor_id = request.POST.get('autor')
        autor = get_object_or_404(CustomUser, id=autor_id)
        
        # Crear la invitación para el autor
        invitacion = InvitacionRevisor(conferencia=conferencia, autor=autor)
        invitacion.save()
        
        return redirect('conferencia/invitaciones_conferencia.html', conferencia_id=conferencia.id)

    # Para el caso en que la petición sea GET, obtener todos los autores disponibles.
    autores_disponibles = CustomUser.objects.filter(rol='Autor')  # Solo autores

    # Obtener las invitaciones ya enviadas para esta conferencia
    invitaciones = InvitacionRevisor.objects.filter(conferencia=conferencia)

    return render(request, 'conferencia/invitar_autor.html', {
        'conferencia': conferencia,
        'autores_disponibles': autores_disponibles,
        'invitaciones': invitaciones
    })

