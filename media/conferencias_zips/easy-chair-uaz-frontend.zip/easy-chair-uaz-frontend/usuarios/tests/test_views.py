import logging

from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.test import TestCase, Client
from django.urls import reverse

from conferencia.models import InvitacionRevisor, Conferencia

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

User = get_user_model()


class UsuariosViewsTest(TestCase):
    def setUp(self):
        logger.info(
            "[UsuariosViewsTest] setUp: inicializando Client y datos de usuario")
        self.client = Client()
        for name in ['Autor', 'Organizador', 'Revisor', 'Administrador']:
            Group.objects.get_or_create(name=name)
        self.user = User.objects.create_user(
            username='autor@example.com',
            email='autor@example.com',
            password='TestPass1!',
            nombre='Autor',
            apellidos='Unit',
            area_conocimiento='Ingenieria'
        )
        autor_group = Group.objects.get(name='Autor')
        self.user.groups.add(autor_group)
        logger.info(
            "[UsuariosViewsTest] Usuario autor creado y agregado al grupo Autor")

    def test_login_get(self):
        logger.info("[test_login_get] iniciando")
        response = self.client.get(reverse('login'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'usuarios/login.html')
        logger.info("[test_login_get] completado")

    def test_login_post_valid(self):
        logger.info("[test_login_post_valid] iniciando")
        data = {'username': 'autor@example.com', 'password': 'TestPass1!'}
        response = self.client.post(reverse('login'), data=data)
        self.assertEqual(response.url, reverse('vistaAutor'))
        logger.info("[test_login_post_valid] completado")

    def test_login_post_invalid(self):
        logger.info("[test_login_post_invalid] iniciando")
        data = {'username': 'wrong@example.com', 'password': 'bad'}
        response = self.client.post(reverse('login'), data=data)
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Usuario o contraseña incorrectos.")
        logger.info("[test_login_post_invalid] completado")

    def test_logout_redirect(self):
        logger.info("[test_logout_redirect] iniciando")
        self.client.login(username='autor@example.com', password='TestPass1!')
        response = self.client.get(reverse('logout'))
        self.assertRedirects(response, reverse('login'))
        logger.info("[test_logout_redirect] completado")

    def test_registro_get(self):
        logger.info("[test_registro_get] iniciando")
        response = self.client.get(reverse('registro'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'usuarios/registro.html')
        logger.info("[test_registro_get] completado")

    def test_registro_post_valid(self):
        logger.info("[test_registro_post_valid] iniciando")
        data = {
            'nombre': 'New',
            'apellidos': 'User',
            'email': 'new@example.com',
            'password1': 'NewPass1!',
            'password2': 'NewPass1!',
            'area_conocimiento': 'Medicina'
        }
        response = self.client.post(reverse('registro'), data=data)
        self.assertRedirects(response, reverse('login'))
        self.assertTrue(User.objects.filter(email='new@example.com').exists())
        logger.info("[test_registro_post_valid] completado")

    def test_registro_post_duplicate_email(self):
        logger.info("[test_registro_post_duplicate_email] iniciando")
        User.objects.create_user(
            username='dup@example.com',
            email='dup@example.com',
            password='DupPass1!',
            nombre='Dup', apellidos='User', area_conocimiento='Letras'
        )
        data = {
            'nombre': 'Dup',
            'apellidos': 'User',
            'email': 'dup@example.com',
            'password1': 'DupPass1!',
            'password2': 'DupPass1!',
            'area_conocimiento': 'Letras'
        }
        response = self.client.post(reverse('registro'), data=data)
        self.assertEqual(response.status_code, 200)
        form = response.context.get('form')
        self.assertIsNotNone(
            form, "El contexto debe contener el form con errores")
        self.assertIn('email', form.errors)
        logger.info(
            "[test_registro_post_duplicate_email] errores recibidos: %s", form.errors.as_json())
        logger.info("[test_registro_post_duplicate_email] completado")

    def _login_as_admin(self):
        admin = User.objects.create_user(
            username='admin@example.com',
            email='admin@example.com',
            password='AdminPass1!',
            nombre='Admin', apellidos='User', area_conocimiento='Contabilidad'
        )
        admin.groups.add(Group.objects.get(name='Administrador'))
        self.client.login(username='admin@example.com', password='AdminPass1!')
        return admin

    def test_admin_dashboard(self):
        logger.info("[test_admin_dashboard] iniciando")
        self._login_as_admin()
        response = self.client.get(reverse('admin_dashboard'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'usuarios/admin_dashboard.html')
        self.assertIn('users', response.context)
        logger.info("[test_admin_dashboard] completado")

    def test_actualizar_roles(self):
        logger.info("[test_actualizar_roles] iniciando")
        admin = self._login_as_admin()
        user2 = User.objects.create_user(
            username='user2@example.com', email='user2@example.com', password='Pass1!',
            nombre='User', apellidos='Two', area_conocimiento='Letras'
        )
        data = {f'roles_{user2.id}_organizador': 'on'}
        response = self.client.post(reverse('actualizar_roles'), data=data)
        self.assertRedirects(response, reverse('admin_dashboard'))
        self.assertTrue(user2.groups.filter(name='Organizador').exists())
        logger.info("[test_actualizar_roles] completado")

    def test_vistaAutor_requires_login(self):
        logger.info("[test_vistaAutor_requires_login] iniciando")
        url = reverse('vistaAutor')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 302)
        logger.info("[test_vistaAutor_requires_login] completado")

    def test_vistaAutor_content(self):
        logger.info("[test_vistaAutor_content] iniciando")
        self.client.login(username='autor@example.com', password='TestPass1!')
        response = self.client.get(reverse('vistaAutor'))
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.context['is_revisor'] in [True, False])
        self.assertTemplateUsed(response, 'usuarios/vistaAutor.html')
        logger.info("[test_vistaAutor_content] completado")

    def test_invitaciones_autor_view(self):
        logger.info("[test_invitaciones_autor_view] iniciando")
        self.client.login(username='autor@example.com', password='TestPass1!')
        response = self.client.get(reverse('invitaciones_autor'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'usuarios/invitaciones.html')
        self.assertIn('invitaciones', response.context)
        logger.info("[test_invitaciones_autor_view] completado")

    def test_responder_invitacion_accept(self):
        logger.info("[test_responder_invitacion_accept] iniciando")
        conf = Conferencia.objects.create(nombre='Conf Test')
        inv = InvitacionRevisor.objects.create(
            autor=self.user, conferencia=conf)
        self.client.login(username='autor@example.com', password='TestPass1!')
        self.client.post(reverse('responder_invitacion', args=[
                         inv.id]), data={'respuesta': 'aceptar'})
        inv.refresh_from_db()
        self.assertEqual(inv.estado, 'Aceptado')
        self.assertTrue(self.user.groups.filter(name='Revisor').exists())
        logger.info("[test_responder_invitacion_accept] completado")

    def test_responder_invitacion_reject(self):
        logger.info("[test_responder_invitacion_reject] iniciando")
        conf = Conferencia.objects.create(nombre='Conf Test')
        inv = InvitacionRevisor.objects.create(
            autor=self.user, conferencia=conf)
        self.client.login(username='autor@example.com', password='TestPass1!')
        self.client.post(reverse('responder_invitacion', args=[
                         inv.id]), data={'respuesta': 'rechazar'})
        inv.refresh_from_db()
        self.assertEqual(inv.estado, 'Rechazado')
        logger.info("[test_responder_invitacion_reject] completado")
